ajax_request_template method cannot load *.tmpl files when requested from puhlic.
ajax_request_template method can load *.html.tmpl files when requested from puhlic.